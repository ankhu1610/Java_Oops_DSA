import java.util.Scanner;

public class tournament_class {
    public static void main(String[] args) {
        System.out.println("enter the number ");
        int num = new Scanner(System.in).nextInt();
        int arr[] = new int[num];
        System.out.println("ENTER ELEMENTS FOR ARRAY");
        for (int i = 0 ;i< num ;i++)
        {
            arr[i] = new Scanner(System.in).nextInt();
        }
        int max[] = new int[(num/2)];
        int min[] = new int[(num/2)];
        if(num%2 == 0) {
            int j = 0;
            for (int i = 0; i < num; i+= 2) {

                if(arr[i] > arr[i+1])
                {
                    max[j] = arr[i];
                    min[j] = arr[i+1];
                }
                else
                {
                    max[j] = arr[i+1];
                    min[j] = arr[i];
                }

                j++;
            }
            int min1 = min[0];
            int max1= max[0];
            for(int i = 1;i<j;i++)
            {
                if(min1 > min[i])
                {
                    min1 = min[i];

                }
                if(max1 < max[i])
                {
                    max1 = max[i];
                }

            }
            System.out.println("minimum"+ min1);
            System.out.println("maximum "+ max1);
        }
        else
        {

            int j = 0;
            for (int i =0;i<num-1 ;i+= 2)
            {
                if(arr[i] > arr[i+1])
                {
                    max[j] = arr[i];
                    min[j] = arr[i+1];
                }
                else
                {
                    max[j] = arr[i+1];
                    min[j] = arr[i];
                }
                j++;
            }
            int min1 = min[0];
            int max1= max[0];
            for(int i = 1;i< (num-1)/2;i++)
            {
                if(min1 > min[i])
                {
                    min1 = min[i];
                    

                }
                if(max1 < max[i])
                {
                    max1 = max[i];
                    System.out.println(max1);
                }
            }
            if(min1 > arr[num-1])
            {

                System.out.println("minimum element is "+arr[num-1]);
                System.out.println("maximum element is "+max1);
            }
            else if(max1 < arr[num-1])
            {
                System.out.println("minimum element is "+min1);
                System.out.println("maximum element is "+arr[num-1]);
            }
            else
            {
                System.out.println("minimum element is "+min1);
                System.out.println("maximum element is "+max1);
            }
        }
    }
}
