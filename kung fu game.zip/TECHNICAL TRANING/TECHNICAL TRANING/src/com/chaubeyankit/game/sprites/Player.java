package com.chaubeyankit.game.sprites;

import com.chaubeyankit.game.utils.GameConstant;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;

public class Player extends Sprites  implements GameConstant  {
//    private int x;
//    private int y;
//    private int w;
//    private int h;
    private int speed = 0;
    private int index = 0;

    private BufferedImage bf;
    private BufferedImage[] walkImages = new BufferedImage[4];
    private BufferedImage[] kickImages = new BufferedImage[3];
    private boolean isJump;
    private int force;
    private boolean isAttacking;

    public Player() throws Exception
    {
        x  = 180;
        h = 100;
        y = FLOOR - h;
        w = 100;
        currentMove = WALK;
        force = 0;

        bf = ImageIO.read(Player.class.getResource("sprite.gif"));



        setWalkImages();
        setKickImages();
    }
    public void setAttacking(boolean setAttacking)
    {
        this.isAttacking = setAttacking;
    }
    public boolean getAttacking()
    {
        return isAttacking;
    }

    public void setSpeed(int speed)
    {
        this.speed = speed;
        if(speed == 0)
        {
            currentMove = WALK;
        }
    }
    void setWalkImages()
    {
        walkImages[0] = bf.getSubimage(211, 5, 24, 44);
        walkImages[1] = bf.getSubimage(235, 2, 18, 49);
    }
    void setKickImages()
    {
        kickImages[0] = bf.getSubimage(211,50,37,45);
//        kickImages[1] = bf.getSubimage(250,52,27,40);
        kickImages[1] = bf.getSubimage(276, 56,23, 37);

    }
    public void jump() {
        if(!isJump) {
//            System.out.println("Call Jump...");
            force = -13;
            y = y + force;
            isJump = true;
        }
    }

    public void fall() {
//		System.out.println("F "+(FLOOR-h));
//		System.out.println("Y "+y);
        if(y>=(FLOOR-h)) {
            isJump= false; // Jump Complete
            //System.out.println("Not Fall");
            return ;
        }
        //System.out.println("Fall....");
        force = force + GRAVITY;
        y= y + force;
    }
    public void move()
    {
        x = x+speed;
    }
    public boolean isAttacking()
    {
        return isAttacking;
    }


    private BufferedImage showWalkPlayer()
    {
        if(index > 1)
        {
            index = 0;
        }
        return walkImages[index++];
    }
    private BufferedImage showKickPlayer()
    {
        if(index > 1)
        {
            index = 0;
            currentMove = WALK;
            isAttacking = false;
        }
        return kickImages[index++];
    }
    @Override
    public void printSprite(Graphics pen) {
        if(currentMove == WALK) {
            pen.drawImage(showWalkPlayer(),x, y, w, h, null);
        }

        else if (currentMove == KICK) {

            pen.drawImage(showKickPlayer(),x, y, w, h, null);
        }
    }

}
