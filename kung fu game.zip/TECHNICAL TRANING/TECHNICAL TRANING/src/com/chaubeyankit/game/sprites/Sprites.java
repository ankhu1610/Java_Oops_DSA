package com.chaubeyankit.game.sprites;

import com.chaubeyankit.game.utils.GameConstant;
import org.encryption.view.FileReading;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;

public abstract class Sprites implements GameConstant {
//    protected static BufferedImage bi;
    protected int x;
    protected  int y;
    protected int w;
    protected int h;
    protected BufferedImage bi;
    protected int speed;
    protected  int currentMove ;
    protected  int index;
    protected  boolean isCollide;
    protected boolean isAlive;
    protected int health;

    Sprites() throws Exception
    {
        bi = ImageIO.read(Player.class.getResource("sprite.gif"));
        h = 100;
        w = 100;
        y = FLOOR -h;
        isAlive = true;

    }

    public int getHealth() {
        return health;
    }

    public boolean isCollide() {
        return isCollide;
    }

    public void setCollide(boolean isCollide )
    {
        this.isCollide = isCollide;
    }

    public int getW()
    {
        return w;
    }

    public int getH()
    {
        return  h;
    }

    public int getX()
    {
        return x;
    }

    public int getY()
    {
        return  y;
    }

    public void setCurrentMove(int currentMove)
    {
        this.currentMove = currentMove;
        index = 0;
//        return this.currentMove;
    }

    public int getCurrentMove()
    {
        return currentMove;
    }

    public void move()
    {
        x = x+ speed;
    }
    public int getCurrentSpeed()
    {
        return speed;
    }
    public void setSpeed(int speed) {
        this.speed = speed;
    }
    public BufferedImage getSpriteImage() {
        return bi;
    }

    public  abstract void printSprite(Graphics pen);

}
