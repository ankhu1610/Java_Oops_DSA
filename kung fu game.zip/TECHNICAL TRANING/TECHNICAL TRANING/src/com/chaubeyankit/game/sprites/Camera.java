package com.chaubeyankit.game.sprites;

import com.chaubeyankit.game.screen.Board;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;

public class Camera extends Sprites {
    BufferedImage backgroundImage;
    BufferedImage partOfImage;
    public Camera() throws Exception {
        super();
         x = 0;
         y = 0;
         w = 1000;
         h = 200;
        try {
            backgroundImage = ImageIO.read(Board.class.getResource("game-bg.png"));
            partOfImage = backgroundImage.getSubimage(x,y,w, h);
        }
        catch(Exception ex) {
            //JOptionPane.showMessageDialog(this,"OOPS something went wrong..");
            System.out.println(ex);
            System.exit(0);

        }
    }

    @Override
    public void printSprite(Graphics pen) {
        partOfImage = backgroundImage.getSubimage(x,y,w, h);
        pen.drawImage(partOfImage, 0,0,GWIDTH,GHEIGHT ,null);
    }
}