package com.chaubeyankit.game.screen;

import jaco.mp3.player.MP3Player;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class SplashScreeen extends JWindow {
    BufferedImage bufferedImage ;
    MP3Player mp3Player ;
    SplashScreeen() throws Exception
    {
        mp3Player = new MP3Player(SplashScreeen.class.getResource("intro.mp3"));

//      bufferedImage = ImageIO.read(SplashScreeen.class.getResource("splash.png"));
        Icon icon =  new ImageIcon(SplashScreeen.class.getResource("splash1.png"));
        mp3Player.play();
//        mp3Player = new MP3Player()
        JLabel jLabel = new JLabel(icon);
        getContentPane().add(jLabel);


        setSize(920,460);
        setLocationRelativeTo(null);


        setVisible(true);
        Thread.sleep(6000);
        mp3Player.stop();

        setVisible(false);
        dispose();


    }

    public static void main(String[] args) {
        try {
            SplashScreeen splashScreeen = new SplashScreeen();

            GameReal gameReal = new GameReal();

        } catch (Exception e) {
            e.printStackTrace();
        }


    }
}
