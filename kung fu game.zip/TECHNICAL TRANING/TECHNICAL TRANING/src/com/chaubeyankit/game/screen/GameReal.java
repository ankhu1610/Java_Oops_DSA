package com.chaubeyankit.game.screen;


import com.chaubeyankit.game.utils.GameConstant;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.image.BufferedImage;


public class GameReal extends JFrame implements GameConstant {
//	BufferedImage bf ;
	
    GameReal() throws  Exception
    {
        setTitle(TITLE);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);


        Board   bd = new Board();
//            bf = ImageIO.read(Board.class.getResource("game-bg.jpeg"));

        add(bd);
        setSize(GWIDTH,GHEIGHT);
        setLocationRelativeTo(null);
        setVisible(true);
        
    }
    public static void main(String[] args) {
        try {


            GameReal gm = new GameReal();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        
        
    }
}
