package com.chaubeyankit.game.screen;

import com.chaubeyankit.game.sprites.Camera;
import com.chaubeyankit.game.sprites.Enemy;
import com.chaubeyankit.game.sprites.Player;
import com.chaubeyankit.game.sprites.Power;
import com.chaubeyankit.game.utils.EnemyTypeCord;
import com.chaubeyankit.game.utils.GameConstant;
import jaco.mp3.player.MP3Player;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;

public class Board extends JPanel implements GameConstant {
    private  Camera camera ;
    BufferedImage bf ;
    BufferedImage partOfImage;
    Player player ;
    private Timer timer;
    private Enemy enemies[] ;
    private Power power;
    private boolean isGameOver;
    MP3Player mp3Player1;
    Board() throws Exception
    {

        mp3Player1 = new MP3Player(GameReal.class.getResource("gaming.mp3"));
        mp3Player1.play();
        power = new Power();
        player = new Player();

        EnemyTypeCord.loadBatAttackEnemy(player.getSpriteImage());
        EnemyTypeCord.loadHandAttackEnemy(player.getSpriteImage());
        EnemyTypeCord.loadKnifeAttackEnemy(player.getSpriteImage());
        enemies = new Enemy[10];
        power = new Power();
        loadEnemies();
        loadBackgroundImage();
        setFocusable(true);
        bindEvents();
        gameLoop();

    }
    private void loadEnemies() throws Exception {
        int gap = 0;
        for(int i = 0 ; i<enemies.length; i++) {
            if(i%2==0) {
                enemies[i] = new Enemy(EnemyTypeCord.handAttackEnemy, gap);
            }
            else if(i%3==0) {
                enemies[i] = new Enemy(EnemyTypeCord.knifeAttackEnemy, gap);
            }
            else {
                enemies[i] = new Enemy(EnemyTypeCord.batAttackEnemy, gap);
            }

            gap = gap + 500;
        }
//		enemies[0] = new Enemy(EnemyTypeCord.handAttackEnemy,0);
//		enemies[1] = new Enemy(EnemyTypeCord.batAttackEnemy,500);
//		enemies[2] = new Enemy(EnemyTypeCord.knifeAttackEnemy,1000);
//		enemies[3] = new Enemy(EnemyTypeCord.handAttackEnemy, 1500);
    }
    private void gameLoop()
    {
        timer = new Timer(150, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                repaint();
                player.fall();
                collision();
            }
        });
        timer.start();
    }
    private void bindEvents()
    {
        this.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_LEFT)
                {
                    player.setSpeed(-10);
                    player.move();
                }
                else if(e.getKeyCode() == KeyEvent.VK_RIGHT)
                {
                    if(player.getX()<=200 )
                    {
                        player.setSpeed(10);
                        player.move();
                    }
                    else {
                        if(camera.getX() < 780) {
                            camera.setSpeed(10);
                            camera.move();
                        }
                        else
                        {
                            if(player.getX() < (GWIDTH-player.getW())) {
                                player.setSpeed(10);
                                player.move();
                            }

                        }
                    }
                }
                else if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                    player.jump();
                }
                else if(e.getKeyCode() == KeyEvent.VK_K)
                {
                    player.setAttacking(true);
                    player.setCurrentMove(KICK);
//                    System.out.println("attacking");

                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
                player.setSpeed(0);
                player.setAttacking(false);
            }
        });
    }

    private void loadBackgroundImage() throws Exception {
        camera = new Camera();
    }
//    private boolean isCollide(Enemy currentEnemy)
//    {
//        int xDistance = Math.abs(player.getX() - currentEnemy.getX());
//        int yDistance = Math.abs(player.getY() - currentEnemy.getY());
//        int maxWidth = Math.max(player.getW(), currentEnemy.getW());
//        int maxHeight = Math.max(player.getH(), currentEnemy.getH());
//        return xDistance<=maxWidth-player.getW() && yDistance<=maxHeight- player.getH();
//    }
private boolean isCollide(Enemy currentEnemy) {
    int xDistance = Math.abs(player.getX() - currentEnemy.getX());
    int yDistance = Math.abs(player.getY() - currentEnemy.getY());
    int maxWidth = Math.max(player.getW(), currentEnemy.getW());
    int maxHeight = Math.max(player.getH(), currentEnemy.getH());
    return xDistance<=maxWidth-50 && yDistance<=maxHeight-40;
}
//
//public void collision() {
//    for(Enemy enemy : enemies) {
//        if(!enemy.isCollide()  && isCollide(enemy)) {
//            if(player.isAttacking()) {
//                enemy.setAlive(false);
//            }
//            else {
//
//                power.setHealth();
//            }
//            enemy.setCollide(true);
//            if(power.getHealth()<=0) {
//                player.setCurrentMove(FALL);
//                isGameOver = true;
//            }
//            System.out.println("Collide......");
//        }
//    }
//}


    public void collision() {
        for(Enemy enemy : enemies) {
            if(!enemy.isCollide()  && isCollide(enemy)) {
                if(player.isAttacking()) {
                    enemy.setAlive(false);
                }
                else {

                    power.setHealth();
                }
                enemy.setCollide(true);
                if(power.getHealth()<=0) {
                    player.setCurrentMove(FALL);
                    isGameOver = true;
                }
                System.out.println("Collide......");
            }
        }
    }


//
//    @Override
//    public void paintComponent(Graphics g)
//    {
//        super.paintComponent(g);
//
//
////       g.drawImage(bf,0,0,1400,890,null);
//       create(g);
//
//        player.printSprite(g);
//        printEnemies(g);
//        power.printSprite(g);
//
//    }

    @Override
    public void paintComponent(Graphics pen) {
        super.paintComponent(pen);
        create(pen);
        player.printSprite(pen);
        printEnemies(pen);
        if(isGameOver) {
            printGameOver(pen);
        }
        power.printSprite(pen);
        //enemy.printSprite(pen);
        //System.out.println("I am the Paint Component....");
    }

    private boolean isVisible = true;
    private void printGameOver(Graphics pen) {
        pen.setColor(Color.BLACK);
        pen.setFont(new Font("Arial", Font.BOLD, 40));
        pen.drawString(isVisible?"Game Over":"", GWIDTH/2, GHEIGHT/2);
        isVisible = !isVisible;
    }

    private void printEnemies(Graphics pen) {
        for(Enemy en: enemies) {
            if(en.isAlive())
                en.printSprite(pen);

        }
    }

    private void create(Graphics g)
    {
        camera.printSprite(g);
//        g.drawImage(partOfImage,0,0,GWIDTH,GHEIGHT,null);
    }
}