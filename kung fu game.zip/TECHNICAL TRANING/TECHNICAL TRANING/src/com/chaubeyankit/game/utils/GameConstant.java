package com.chaubeyankit.game.utils;

public interface GameConstant {
    String TITLE  = "My first game";
    int GWIDTH = 1400;
    int GHEIGHT = 400;
    int FLOOR  = 320;
    int KICK = 2;
    int WALK = 1;
    int GRAVITY = 1;
    int MAX_ENEMIES = 10;
    int FALL = 3;
    int MAX_HEALTH  = 200;
    
}
